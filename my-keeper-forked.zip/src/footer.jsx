import React from "react";

export default function Footer() {
  return <footer>Copyrights &copy; hassanoof</footer>;
}
